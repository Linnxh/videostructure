create procedure sp_split(IN c1 varchar(2000), IN split1 varchar(20))
  BEGIN
CREATE TEMPORARY TABLE IF NOT EXISTS temp_split
(
   col varchar(20)
);
DELETE FROM temp_split;
while(instr(c1,split1)<>0) DO
insert temp_split(col) values (substring(c1,1,instr(c1,split1)-1));
set c1 = INSERT(c1,1,instr(c1,split1),'');
END WHILE;
insert temp_split(col) values (c1); 
END;


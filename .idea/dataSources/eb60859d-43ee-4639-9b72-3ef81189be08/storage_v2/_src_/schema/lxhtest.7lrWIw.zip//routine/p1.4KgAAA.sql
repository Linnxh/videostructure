create procedure p1()
  BEGIN
    DECLARE i INT;
    SET i = 0;
    WHILE i < 119 DO
      INSERT INTO test (uname, age) VALUES ('lxh', i);
      SET i = i + 1;
    END WHILE;
  END;


create procedure superadmin_role_reso()
  BEGIN
    DECLARE i INT;
    SET i = 0;
    WHILE i < 119 DO
      INSERT INTO test (uname, age) VALUES ('名字'+i, i);
      SET i = i + 1;
    END WHILE;
  END;


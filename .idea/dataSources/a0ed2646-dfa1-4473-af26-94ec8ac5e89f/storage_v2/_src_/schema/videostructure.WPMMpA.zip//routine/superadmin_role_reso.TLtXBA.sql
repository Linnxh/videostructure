create procedure superadmin_role_reso()
  BEGIN
    DECLARE i INT;
    SET i = 1;
    WHILE i < 200 DO
      INSERT INTO sys_role_reso ( role_id, reso_id) VALUES ( 4, i);
      SET i = i + 1;
    END WHILE;
  END;

